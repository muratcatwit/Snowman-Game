The idea for this game is that marriage is inevitable, and you must cling to your bachelorhood. Do this by steaking out territory in your local school before the cooties catch you.
